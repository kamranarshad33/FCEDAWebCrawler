import { Component, OnInit } from '@angular/core';
import { WordsService } from './words.service';


 
@Component({
  selector: 'app-keywords',
  styleUrls: ['./keywords.component.css'],
  template: 
  `
    <h2>Keywords</h2>
  
    <input 
      (keyup.enter)="createKeyWord(keyword)" #keyword
      type="text" class="form-control">
    

      
    <button (click)="getWord(); toggleDisplay();"><span>Show Keywords </span></button>
    <div *ngIf = "!isShow">
      <ul class="list-group">
        <li 
          *ngFor="let keyword of keywords"
          class="list-group-item">
          {{ keyword }} <button (click)="deleteWord(keyword)">Delete</button>
        </li>
      </ul>
  </div>
  <br />
`,

styles:
  [
    'button { background-color: #1D809F; color: #fff; font-weight: bold;}',
      'button span {cursor: pointer; display: inline-block; transition: 0.3s; }',
      'button span:after {content: "\\00BB\"; opacity: 0; top: 0; right: -20px; transition: 0.3s;}',
      'button:hover span { padding-right: 7px; }',
      'button:hover span:after {opacity: 1; right: 0;}',
      'minus {content: "\\2212\";}',
      '.delete {background-color: red; color: #fff; cursor: pointer; font-size:11px; transition-duration: 0.4s;}',
      '.delete:hover {color:white; background-color: #A80000;}'
  ]
  
})

export class KeywordsComponent implements OnInit {
keywords;
isShow = true;

constructor(private wordService: WordsService) {}

ngOnInit() {

}

getWord() {
  this.wordService.getWords()
  .subscribe(response => {
    this.keywords = response;
  });
}

createKeyWord(keyword: HTMLInputElement) {
  this.wordService.postKeyword(keyword);
}

toggleDisplay() {
  this.isShow = !this.isShow;
}

deleteWord(keyword: string) {
  this.wordService.deleteKeyword(keyword).subscribe(
    () => console.log(`Keyword: = ${keyword} deleted.`),
    (err) => console.log(err)
  );
}


}



