export class Keyword {
    id: number;
    keyword: string;

    constructor(id: number, keyword: string)
    {
        this.id = id;
        this.keyword = keyword;
    }

}
   








