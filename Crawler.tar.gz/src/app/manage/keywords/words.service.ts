import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
 


 
@Injectable({
    providedIn: 'root'
})
export class WordsService implements OnInit{

    constructor(private httpClient: HttpClient) { }

    ngOnInit() {

    }

    url: string = "/api/keywords"
    url2: string = "/api/addKeyword";
    url3: string = "/api/deleteKeyword";
   

    
    getWords(){
        return this.httpClient.get(this.url);
    }


    postKeyword(input: HTMLInputElement){
         const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
         return this.httpClient.post(this.url2, {"keyword": input.value}, 
        {headers: headers}).toPromise().then(posts => 
            {
                console.log(posts);
            });
         
       }
    deleteKeyword(keyword: string): Observable<void> {
        const url3 = `/api/deleteKeyword/${ keyword }`;
        const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
        return this.httpClient.delete<void>(url3, {headers: headers});
    }
       
}