import { Component, OnInit } from '@angular/core';
import { WordsService } from './words.service';

@Component({
  selector: 'app-websites',
  styleUrls: ['./websites.component.css'],
  template: `
  <h2>Websites</h2>
  
<input 
    (keyup.enter)="createWebsite(website)" #website
    type="text" class="form-control">
    <button (click)="getWebsite(); toggleDisplay();"><span>Show Websites </span></button>
    

    <div *ngIf = "!isShow">
      <ul class="list-group">
        <li 
            *ngFor="let website of websites"
            class="list-group-item">
            {{ website }}
        </li>
      </ul>
    </div>
  `,

  styles:
  [
    'button { background-color: #1D809F; color: #fff; font-weight: bold;}',
      'button span {cursor: pointer; display: inline-block; transition: 0.3s; }',
      'button span:after {content: "\\00BB\"; opacity: 0; top: 0; right: -20px; transition: 0.3s;}',
      'button:hover span { padding-right: 7px; }',
      'button:hover span:after {opacity: 1; right: 0;}',
      'minus {content: "\\2212\";',
      '.delete {background-color: red; color: #fff; cursor: pointer; font-size:11px; transition-duration: 0.4s;',
      '.delete:hover {color:white; background-color: #A80000;}'
  ]
  
})
export class WebsitesComponent implements OnInit {
  websites;
  isShow = true;


  constructor(private wordService: WordsService) {}
  
  ngOnInit() {
    
    }

    getWebsite() {
      this.wordService.getWebsites()
      .subscribe(response => {
        this.websites = response;
      });
    }
  
  
  
  createWebsite(website: HTMLInputElement) {
    this.wordService.postWebsite(website);
  }

  toggleDisplay() {
    this.isShow = !this.isShow;
  }
  
}
  
  
