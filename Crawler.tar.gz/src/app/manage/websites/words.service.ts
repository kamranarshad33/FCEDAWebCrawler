import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';



 
@Injectable({
    providedIn: 'root'
})
export class WordsService implements OnInit{

    constructor(private httpClient: HttpClient) { }

    ngOnInit() {

    }

    url: string = '/api/websites';
    url2: string = "/api/addWebsite";

    
    getWebsites(){
        return this.httpClient.get(this.url);
    }


    postWebsite(input: HTMLInputElement){
        const headers = new HttpHeaders({ 'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'});
        return this.httpClient.post(this.url2, {"website": input.value}, 
       {headers: headers}).toPromise().then(posts => {
           console.log(posts);
       });
  


    }
}
