export class Words {
    abstract: string;
    category: string;
    date: string;
    link: string;

    constructor(abstract, category, date, link)
    {
        this.abstract = abstract;
        this.category = category;
        this.date = date;
        this.link = link;
    }

}
   








