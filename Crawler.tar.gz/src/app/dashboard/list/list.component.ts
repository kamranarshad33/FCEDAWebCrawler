import { Component, OnInit } from '@angular/core';
import { WordsService } from './words.service';


@Component({
  selector: 'app-list',
  /*templateUrl: './list.component.html',*/
  styleUrls: ['./list.component.css'],
  template: `
  <div class="row">
  <table>
    <thead>
    <tr>
      <th>Date</th>
      <th>Category</th>
      <th>Link</th>
      <th>Abstract</th>
    </tr>
    </thead>
    <tbody>
    <tr *ngFor="let word of words;">
      <td>{{ word.date }}</td>
      <td>{{ word.category }}</td>
      <td><a [href] = "word.link" target="_blank">{{ word.link }}</a></td>
      <td>{{ word.abstract }}</td>
    </tr>
    </tbody>
  </table>
</div>
  
  `
  
})
export class ListComponent implements OnInit {

public words = [];

  constructor(private _wordsService: WordsService) {}


  ngOnInit(){

   this._wordsService.getWords()
      .subscribe(data => this.words = data);
  
  }
 

}
