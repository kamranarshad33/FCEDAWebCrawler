export class Words {
    date: string;
    category: string;
    link: string;
    abstract: string;



constructor(date, category, link, abstract) {
    this.date = date;
    this.category = category;
    this.link = link;
    this.abstract = abstract;

    }
}   