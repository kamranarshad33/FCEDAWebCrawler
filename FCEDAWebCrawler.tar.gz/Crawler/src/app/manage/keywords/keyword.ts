export class Keyword {
    word: string;

    constructor(word: string)
    {
        this.word = word;
    }

}
   








