# FCEDAWebCrawler

We will use this repostory to store our codes.

- Crawler.py includes the code that crawls the internet.
- FCEDA_temp.db stores the data in a SQLite DB file temporarily for now.
